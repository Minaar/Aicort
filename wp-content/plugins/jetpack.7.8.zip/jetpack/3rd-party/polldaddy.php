<?php

class Jetpack_Sync {
	static function sync_options() {
		_deprecated_function( __METHOD__, 'jetpack-4.2', 'jetpack_options_whitelist filter' );
	}
}
