module.exports = {
	preset: '@wordpress/jest-preset-default',
	roots: [ '<rootDir>/extensions/' ],
};
