<?php
/**
 * Markdown Block.
 *
 * @since 6.8.0
 *
 * @package Jetpack
 */

jetpack_register_block( 'jetpack/markdown' );
